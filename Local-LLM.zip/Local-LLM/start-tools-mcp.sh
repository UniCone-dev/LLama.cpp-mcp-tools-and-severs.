#!/usr/bin/env bash
source "$SCRIPT_DIR/Local-LLM/mcp-tools/venv/bin/activate"
cd "$SCRIPT_DIR/Local-LLM/mcp-tools"
python server.py
