from mcp.server.fastmcp import FastMCP
from ddgs import DDGS

mcp = FastMCP("web-search")

@mcp.tool()
def web_search(query: str, max_results: int = 5) -> str:
    """Search the web using DuckDuckGo and return top results with titles, links, and snippets."""
    with DDGS() as ddgs:
        results = list(ddgs.text(query, max_results=max_results))
    if not results:
        return "No results found."
    out = []
    for r in results:
        out.append(f"- {r.get('title')}\n  {r.get('href')}\n  {r.get('body')}")
    return "\n\n".join(out)

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
