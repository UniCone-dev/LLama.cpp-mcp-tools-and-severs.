#!/usr/bin/env bash
source "$SCRIPT_DIR/Local-LLM/mcp-websearch/venv/bin/activate"
cd "$SCRIPT_DIR/Local-LLM/mcp-websearch"
python server.py
