from mcp.server.fastmcp import FastMCP
from ddgs import DDGS
import httpx
from bs4 import BeautifulSoup
import wikipedia
import subprocess
import json
import os
from datetime import datetime

mcp = FastMCP("core-tools", stateless_http=True)

MEMORY_FILE = os.path.expanduser("~/Local-LLM/memory/memory.json")

def _load_memories():
    if not os.path.exists(MEMORY_FILE):
        return []
    with open(MEMORY_FILE, "r") as f:
        return json.load(f)

def _save_memories(memories):
    with open(MEMORY_FILE, "w") as f:
        json.dump(memories, f, indent=2)

@mcp.tool()
def save_memory(content: str) -> str:
    """Save an important fact about the user or conversation for future recall across all chats. Use this whenever the user shares something worth remembering long-term (preferences, projects, names, ongoing tasks)."""
    memories = _load_memories()
    memories.append({"content": content, "saved_at": datetime.now().isoformat()})
    _save_memories(memories)
    return f"Saved to long-term memory: {content}"

@mcp.tool()
def search_memory(query: str = "") -> str:
    """Search or list previously saved memories. Call this at the start of a new chat or when the user references something from before."""
    memories = _load_memories()
    if not memories:
        return "No memories saved yet."
    if query:
        matches = [m for m in memories if query.lower() in m["content"].lower()]
        if not matches:
            return f"No memories matching '{query}'."
        memories = matches
    return "\n".join(f"- {m['content']} (saved {m['saved_at'][:10]})" for m in memories)

@mcp.tool()
def delete_memory(content_snippet: str) -> str:
    """Delete a saved memory that matches the given text snippet."""
    memories = _load_memories()
    remaining = [m for m in memories if content_snippet.lower() not in m["content"].lower()]
    removed = len(memories) - len(remaining)
    _save_memories(remaining)
    return f"Removed {removed} memory/memories matching '{content_snippet}'."

@mcp.tool()
def web_search(query: str, max_results: int = 5) -> str:
    """Search the web using DuckDuckGo. Returns titles, links, and snippets."""
    with DDGS() as ddgs:
        results = list(ddgs.text(query, max_results=max_results))
    if not results:
        return "No results found."
    return "\n\n".join(f"- {r.get('title')}\n  {r.get('href')}\n  {r.get('body')}" for r in results)

@mcp.tool()
def read_webpage(url: str, max_chars: int = 4000) -> str:
    """Fetch a URL and return its readable text content."""
    try:
        resp = httpx.get(url, timeout=15, follow_redirects=True,
                          headers={"User-Agent": "Mozilla/5.0"})
        soup = BeautifulSoup(resp.text, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()
        text = " ".join(soup.get_text(separator=" ").split())
        return text[:max_chars]
    except Exception as e:
        return f"Error fetching page: {e}"

@mcp.tool()
def wikipedia_search(query: str, sentences: int = 5) -> str:
    """Search Wikipedia and return a summary of the most relevant article."""
    try:
        return wikipedia.summary(query, sentences=sentences, auto_suggest=True)
    except wikipedia.DisambiguationError as e:
        return f"Multiple matches found: {', '.join(e.options[:5])}"
    except Exception as e:
        return f"Error: {e}"

@mcp.tool()
def run_python(code: str) -> str:
    """Execute a Python snippet for calculations/scripts. 10 second timeout."""
    try:
        result = subprocess.run(["python3", "-c", code], capture_output=True, text=True, timeout=10)
        out = result.stdout.strip()
        err = result.stderr.strip()
        return out if out else (err if err else "(no output)")
    except subprocess.TimeoutExpired:
        return "Error: execution timed out (10s limit)"
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
