#!/usr/bin/env bash
MODEL_FILE="$SCRIPT_DIR/Local-LLM/models" -name "*.gguf"
cd "$SCRIPT_DIR/Local-LLM/llama.cpp"
echo "Model is Starting Pleses Wait ....."
( sleep 3 && xdg-open "http://127.0.0.1:8080" >/dev/null 2>&1 & )
./build/bin/llama-server \
    -m "$MODEL_FILE" \
    -ngl #pleses write by your self \
    -c #pleses write by your self \
    --parallel 1 \
    --cache-type-k q4_0 --cache-type-v q4_0 \
    --host 127.0.0.1 --port 8080 \
    --tools all --jinja
